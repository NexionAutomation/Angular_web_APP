import { CRUD } from './crud';

describe('CRUD', () => {
  it('should create an instance', () => {
    expect(new CRUD()).toBeTruthy();
  });
});
