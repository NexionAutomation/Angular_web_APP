import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-drawing-qrcode',
  templateUrl: './create-drawing-qrcode.component.html',
  styleUrls: ['./create-drawing-qrcode.component.scss']
})
export class CreateDrawingQrcodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
