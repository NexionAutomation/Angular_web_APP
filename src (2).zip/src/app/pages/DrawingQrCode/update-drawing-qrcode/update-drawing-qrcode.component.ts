import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-drawing-qrcode',
  templateUrl: './update-drawing-qrcode.component.html',
  styleUrls: ['./update-drawing-qrcode.component.scss']
})
export class UpdateDrawingQrcodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
