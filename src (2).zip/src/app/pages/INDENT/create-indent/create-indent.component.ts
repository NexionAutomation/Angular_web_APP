import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-indent',
  templateUrl: './create-indent.component.html',
  styleUrls: ['./create-indent.component.scss']
})
export class CreateIndentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
