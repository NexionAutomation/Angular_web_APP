export const environment = {
    production: true,
 
    apiUrl:'https://localhost:44330/GraphQL',//'https://localhost:44330/GraphQL',//'https://localhost:44330/GraphQL',//'https://localhost:44330/GraphQL',//'https://nexionenterpriseapi.azurewebsites.net/graphql',//'https://localhost:44330/GraphQL',//'https://nexionenterpriseapi.azurewebsites.net/graphql',//'https://localhost:44330/GraphQL',//'https://localhost:44330/GraphQL',//'https://nexionenterpriseapi.azurewebsites.net/graphql',//'https://localhost:44330/GraphQL',// ' http://gph69462-001-site1.ctempurl.com/GraphQL',//,
  imgUrl: 'https://img.dev.com'
};
